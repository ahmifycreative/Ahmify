
'use client';

import { useState, useEffect, useRef } from 'react';

export default function Portfolio() {
  const [isVisible, setIsVisible] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [hoveredProject, setHoveredProject] = useState<number | null>(null);
  const sectionRef = useRef<HTMLDivElement>(null);

  const categories = [
    { id: 'all', name: 'All Projects' },
    { id: 'amazon', name: 'Amazon' },
    { id: 'shopify', name: 'Shopify' },
    { id: 'branding', name: 'Branding' },
    { id: 'tiktok', name: 'TikTok' }
  ];

  const projects = [
    {
      id: 1,
      title: "Celzo – Bold Drink Branding",
      category: "branding",
      description: "Complete brand identity for energy drink startup",
      tags: ["Branding", "Packaging", "Social Media"]
    },
    {
      id: 2,
      title: "Boomstick – Clean Beauty Amazon Images",
      category: "amazon",
      description: "Product listing optimization for beauty brand",
      tags: ["Amazon", "Beauty", "Infographics"]
    },
    {
      id: 3,
      title: "True Classic – Apparel Listing Design",
      category: "amazon",
      description: "Lifestyle and product images for apparel brand",
      tags: ["Amazon", "Apparel", "Lifestyle"]
    },
    {
      id: 4,
      title: "TikTok Viral Campaign Graphics",
      category: "tiktok",
      description: "Social media graphics for viral marketing",
      tags: ["TikTok", "Social Media", "Viral"]
    },
    {
      id: 5,
      title: "Shopify Store Complete Design",
      category: "shopify",
      description: "Full store design with conversion optimization",
      tags: ["Shopify", "E-commerce", "CRO"]
    },
    {
      id: 6,
      title: "Wellness Brand Identity",
      category: "branding",
      description: "Health and wellness brand complete package",
      tags: ["Branding", "Wellness", "Logo"]
    }
  ];

  const filteredProjects = selectedCategory === 'all' 
    ? projects 
    : projects.filter(project => project.category === selectedCategory);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.3 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section ref={sectionRef} className="py-24 bg-white">
      <div className="container mx-auto px-6">
        <div className={`text-center mb-16 transform transition-all duration-1000 ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0'}`}>
          <h2 className="text-5xl font-bold text-gray-900 mb-6">
            Featured <span className="bg-gradient-to-r from-pink-500 to-blue-500 bg-clip-text text-transparent">Work</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Take a look at some of my recent projects that have helped brands boost their sales and stand out.
          </p>
        </div>

        <div className={`flex flex-wrap justify-center gap-4 mb-12 transform transition-all duration-1000 delay-300 ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0'}`}>
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              className={`px-6 py-3 rounded-full font-medium transition-all duration-300 whitespace-nowrap cursor-pointer ${
                selectedCategory === category.id
                  ? 'bg-gradient-to-r from-pink-500 to-blue-500 text-white shadow-lg'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              {category.name}
            </button>
          ))}
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProjects.map((project, index) => (
            <div
              key={project.id}
              className={`group relative rounded-3xl overflow-hidden shadow-lg transition-all duration-500 cursor-pointer transform ${
                isVisible ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0'
              } ${hoveredProject === project.id ? 'scale-105' : ''}`}
              style={{ transitionDelay: `${index * 100}ms` }}
              onMouseEnter={() => setHoveredProject(project.id)}
              onMouseLeave={() => setHoveredProject(null)}
            >
              <div className="aspect-[4/3] relative overflow-hidden">
                <img
                  src={`https://readdy.ai/api/search-image?query=Professional%20ecommerce%20design%20showcase%20for%20${project.title}%2C%20modern%20creative%20layout%2C%20vibrant%20coral%20and%20blue%20color%20palette%2C%20clean%20product%20presentation%2C%20high-quality%20design%20work%2C%20contemporary%20aesthetic%2C%20professional%20portfolio%20piece%2C%20creative%20branding%20elements&width=400&height=300&seq=portfolio-${project.id}&orientation=landscape`}
                  alt={project.title}
                  className="w-full h-full object-cover object-top group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              </div>

              <div className="absolute bottom-0 left-0 right-0 p-6 text-white transform translate-y-full group-hover:translate-y-0 transition-transform duration-300">
                <h3 className="text-xl font-bold mb-2">{project.title}</h3>
                <p className="text-gray-200 mb-4">{project.description}</p>
                <div className="flex flex-wrap gap-2">
                  {project.tags.map((tag, tagIndex) => (
                    <span
                      key={tagIndex}
                      className="px-3 py-1 bg-white/20 rounded-full text-sm backdrop-blur-sm"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>

              <div className="absolute top-4 right-4 w-10 h-10 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <i className="ri-external-link-line text-white"></i>
              </div>
            </div>
          ))}
        </div>

        <div className={`text-center mt-16 transform transition-all duration-1000 delay-500 ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0'}`}>
          <a 
            href="https://drive.google.com/drive/u/4/folders/1venSyhMFwW6aFM6tTT0Anp1nk-oQwF-T"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block px-8 py-4 bg-gradient-to-r from-pink-500 to-blue-500 text-white font-semibold rounded-full hover:scale-105 transition-all duration-300 whitespace-nowrap cursor-pointer"
          >
            View Full Portfolio
          </a>
        </div>
      </div>
    </section>
  );
}
