
'use client';

import { useState, useEffect, useRef } from 'react';

export default function Contact() {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.3 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section ref={sectionRef} className="py-24 bg-gradient-to-br from-gray-900 via-purple-900 to-pink-900 text-white relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-black/50 to-transparent"></div>

      <div className="container mx-auto px-6 relative z-10">
        <div className={`text-center mb-16 transform transition-all duration-1000 ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0'}`}>
          <h2 className="text-5xl font-bold mb-6">
            Ready to <span className="bg-gradient-to-r from-pink-400 to-blue-400 bg-clip-text text-transparent">Elevate</span> Your Brand?
          </h2>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            Let's create something amazing together. Drop me a line and let's discuss your next project.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-16 items-start">
          <div className={`transform transition-all duration-1000 delay-300 ${isVisible ? 'translate-x-0 opacity-100' : '-translate-x-20 opacity-0'}`}>
            <div className="space-y-8">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-gradient-to-r from-pink-500 to-blue-500 rounded-full flex items-center justify-center">
                  <i className="ri-mail-fill text-white text-xl"></i>
                </div>
                <div>
                  <h3 className="text-xl font-bold">Email</h3>
                  <p className="text-gray-300">ahmify.creative@gmail.com</p>
                </div>
              </div>

              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-gradient-to-r from-pink-500 to-blue-500 rounded-full flex items-center justify-center">
                  <i className="ri-time-fill text-white text-xl"></i>
                </div>
                <div>
                  <h3 className="text-xl font-bold">Response Time</h3>
                  <p className="text-gray-300">Within 24 hours</p>
                </div>
              </div>

              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-gradient-to-r from-pink-500 to-blue-500 rounded-full flex items-center justify-center">
                  <i className="ri-global-fill text-white text-xl"></i>
                </div>
                <div>
                  <h3 className="text-xl font-bold">Timezone</h3>
                  <p className="text-gray-300">EST (New York)</p>
                </div>
              </div>
            </div>

            <div className="mt-12">
              <h3 className="text-2xl font-bold mb-6">Follow Me</h3>
              <div className="flex space-x-4">
                <a 
                  href="https://be.net/theahmadmalik" 
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center hover:bg-white/20 transition-colors duration-300 cursor-pointer"
                >
                  <i className="ri-behance-fill text-xl"></i>
                </a>
                <a 
                  href="https://www.instagram.com/ahmad_suiii/" 
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center hover:bg-white/20 transition-colors duration-300 cursor-pointer"
                >
                  <i className="ri-instagram-fill text-xl"></i>
                </a>
                <a 
                  href="https://www.linkedin.com/in/ahmadmalikcreative/" 
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center hover:bg-white/20 transition-colors duration-300 cursor-pointer"
                >
                  <i className="ri-linkedin-fill text-xl"></i>
                </a>
                <a 
                  href="#" 
                  className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center hover:bg-white/20 transition-colors duration-300 cursor-pointer"
                >
                  <i className="ri-twitter-fill text-xl"></i>
                </a>
              </div>
            </div>
          </div>

          <div className={`transform transition-all duration-1000 delay-500 ${isVisible ? 'translate-x-0 opacity-100' : 'translate-x-20 opacity-0'}`}>
            <div className="bg-white/10 backdrop-blur-sm rounded-3xl p-8 space-y-6">
              <div className="text-center">
                <div className="w-16 h-16 bg-gradient-to-r from-pink-500 to-blue-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="ri-message-3-fill text-white text-2xl"></i>
                </div>
                <h3 className="text-2xl font-bold mb-4">Get In Touch</h3>
                <p className="text-gray-300 mb-6">
                  Ready to start your next project? Reach out through any of the contact methods on the left, and I'll get back to you within 24 hours.
                </p>
                <a 
                  href="mailto:ahmify.creative@gmail.com"
                  className="inline-block px-8 py-4 bg-gradient-to-r from-pink-500 to-blue-500 text-white font-semibold rounded-lg hover:scale-105 transition-all duration-300 whitespace-nowrap cursor-pointer"
                >
                  Send Email
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
