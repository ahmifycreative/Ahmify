
'use client';

import { useState, useEffect, useRef } from 'react';

export default function Services() {
  const [isVisible, setIsVisible] = useState(false);
  const [hoveredCard, setHoveredCard] = useState<number | null>(null);
  const sectionRef = useRef<HTMLDivElement>(null);

  const services = [
    {
      title: "Amazon Product Listing Design",
      description: "Eye-catching product images that convert browsers into buyers with compelling infographics and lifestyle shots.",
      icon: "ri-amazon-fill",
      color: "from-orange-400 to-red-500",
      bgColor: "from-orange-50 to-red-50"
    },
    {
      title: "TikTok Visual Concepts",
      description: "Viral-ready graphics and video thumbnails designed for the TikTok generation and mobile-first audiences.",
      icon: "ri-tiktok-fill",
      color: "from-pink-400 to-purple-500",
      bgColor: "from-pink-50 to-purple-50"
    },
    {
      title: "Shopify Store Graphics",
      description: "Complete store designs including banners, product images, and promotional graphics that drive sales.",
      icon: "ri-shopping-bag-fill",
      color: "from-green-400 to-teal-500",
      bgColor: "from-green-50 to-teal-50"
    },
    {
      title: "Branding & Mockups",
      description: "Full brand identity packages with logo design, color schemes, and professional mockups for your products.",
      icon: "ri-paint-brush-fill",
      color: "from-blue-400 to-indigo-500",
      bgColor: "from-blue-50 to-indigo-50"
    }
  ];

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.3 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section ref={sectionRef} className="py-24 bg-gradient-to-br from-gray-50 to-white">
      <div className="container mx-auto px-6">
        <div className={`text-center mb-16 transform transition-all duration-1000 ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0'}`}>
          <h2 className="text-5xl font-bold text-gray-900 mb-6">
            Services That <span className="bg-gradient-to-r from-pink-500 to-blue-500 bg-clip-text text-transparent">Deliver</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            From concept to conversion, I create designs that don't just look good—they perform.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <div
              key={index}
              className={`group relative p-8 rounded-3xl transition-all duration-500 cursor-pointer transform ${
                isVisible ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0'
              } ${hoveredCard === index ? 'scale-105' : ''}`}
              style={{ transitionDelay: `${index * 100}ms` }}
              onMouseEnter={() => setHoveredCard(index)}
              onMouseLeave={() => setHoveredCard(null)}
            >
              <div className={`absolute inset-0 bg-gradient-to-br ${service.bgColor} rounded-3xl opacity-80 group-hover:opacity-100 transition-opacity duration-300`}></div>
              
              <div className="relative z-10">
                <div className={`w-16 h-16 bg-gradient-to-r ${service.color} rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`}>
                  <i className={`${service.icon} text-white text-2xl`}></i>
                </div>
                
                <h3 className="text-xl font-bold text-gray-900 mb-4 group-hover:text-gray-800 transition-colors duration-300">
                  {service.title}
                </h3>
                
                <p className="text-gray-600 leading-relaxed group-hover:text-gray-700 transition-colors duration-300">
                  {service.description}
                </p>
              </div>

              <div className="absolute inset-0 bg-gradient-to-br from-white/20 to-transparent rounded-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
