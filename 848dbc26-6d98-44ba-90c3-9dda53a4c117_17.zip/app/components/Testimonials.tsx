
'use client';

import { useState, useEffect, useRef } from 'react';

export default function Testimonials() {
  const [isVisible, setIsVisible] = useState(false);
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const sectionRef = useRef<HTMLDivElement>(null);

  const testimonials = [
    {
      id: 1,
      name: "Sarah Johnson",
      role: "CEO, Clean Beauty Co.",
      company: "Amazon Seller",
      text: "Ahmad transformed our product listings completely. Our conversion rate increased by 40% within the first month. His understanding of Amazon's visual requirements is exceptional.",
      rating: 5,
      avatar: "https://readdy.ai/api/search-image?query=Professional%20business%20woman%20headshot%2C%20confident%20female%20CEO%2C%20clean%20beauty%20industry%2C%20modern%20professional%20portrait%2C%20bright%20lighting%2C%20contemporary%20business%20attire%2C%20approachable%20smile%2C%20coral%20and%20blue%20color%20palette%20background&width=100&height=100&seq=testimonial-1&orientation=squarish"
    },
    {
      id: 2,
      name: "Marcus Chen",
      role: "Founder, Bold Drinks",
      company: "Shopify Brand",
      text: "Working with Ahmify was a game-changer for our brand. The designs are not just beautiful—they actually convert. Our social media engagement doubled!",
      rating: 5,
      avatar: "https://readdy.ai/api/search-image?query=Professional%20business%20man%20headshot%2C%20confident%20male%20founder%2C%20beverage%20industry%2C%20modern%20professional%20portrait%2C%20bright%20lighting%2C%20contemporary%20business%20attire%2C%20approachable%20smile%2C%20coral%20and%20blue%20color%20palette%20background&width=100&height=100&seq=testimonial-2&orientation=squarish"
    },
    {
      id: 3,
      name: "Emma Rodriguez",
      role: "Marketing Director",
      company: "TikTok-First Brand",
      text: "Ahmad gets the TikTok aesthetic like no other designer. Our campaigns went viral because of his creative vision. Highly recommend for any DTC brand!",
      rating: 5,
      avatar: "https://readdy.ai/api/search-image?query=Professional%20business%20woman%20headshot%2C%20confident%20female%20marketing%20director%2C%20social%20media%20industry%2C%20modern%20professional%20portrait%2C%20bright%20lighting%2C%20contemporary%20business%20attire%2C%20approachable%20smile%2C%20coral%20and%20blue%20color%20palette%20background&width=100&height=100&seq=testimonial-3&orientation=squarish"
    }
  ];

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.3 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  return (
    <section ref={sectionRef} className="py-24 bg-gradient-to-br from-pink-50 via-white to-blue-50">
      <div className="container mx-auto px-6">
        <div className={`text-center mb-16 transform transition-all duration-1000 ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0'}`}>
          <h2 className="text-5xl font-bold text-gray-900 mb-6">
            What Clients <span className="bg-gradient-to-r from-pink-500 to-blue-500 bg-clip-text text-transparent">Say</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Don't just take my word for it—hear from the brands I've helped grow.
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          <div className={`relative transform transition-all duration-1000 delay-300 ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0'}`}>
            <div className="bg-white rounded-3xl shadow-2xl p-12 relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-pink-500 to-blue-500"></div>
              
              <div className="text-center">
                <div className="mb-8">
                  <img
                    src={testimonials[currentTestimonial].avatar}
                    alt={testimonials[currentTestimonial].name}
                    className="w-20 h-20 rounded-full mx-auto mb-4 shadow-lg object-cover object-top"
                  />
                  <div className="flex justify-center mb-4">
                    {[...Array(testimonials[currentTestimonial].rating)].map((_, i) => (
                      <i key={i} className="ri-star-fill text-yellow-400 text-xl"></i>
                    ))}
                  </div>
                </div>

                <blockquote className="text-2xl text-gray-700 leading-relaxed mb-8 font-medium">
                  "{testimonials[currentTestimonial].text}"
                </blockquote>

                <div>
                  <h4 className="text-xl font-bold text-gray-900 mb-1">
                    {testimonials[currentTestimonial].name}
                  </h4>
                  <p className="text-gray-600">
                    {testimonials[currentTestimonial].role} • {testimonials[currentTestimonial].company}
                  </p>
                </div>
              </div>
            </div>

            <div className="flex justify-center mt-8 space-x-3">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentTestimonial(index)}
                  className={`w-3 h-3 rounded-full transition-all duration-300 cursor-pointer ${
                    index === currentTestimonial
                      ? 'bg-gradient-to-r from-pink-500 to-blue-500 w-8'
                      : 'bg-gray-300 hover:bg-gray-400'
                  }`}
                />
              ))}
            </div>
          </div>
        </div>

        <div className={`grid md:grid-cols-3 gap-8 mt-20 transform transition-all duration-1000 delay-500 ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0'}`}>
          <div className="text-center">
            <div className="w-16 h-16 bg-gradient-to-r from-pink-500 to-blue-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <i className="ri-trophy-fill text-white text-2xl"></i>
            </div>
            <h3 className="text-3xl font-bold text-gray-900 mb-2">500+</h3>
            <p className="text-gray-600">Projects Delivered</p>
          </div>

          <div className="text-center">
            <div className="w-16 h-16 bg-gradient-to-r from-orange-500 to-red-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <i className="ri-heart-fill text-white text-2xl"></i>
            </div>
            <h3 className="text-3xl font-bold text-gray-900 mb-2">98%</h3>
            <p className="text-gray-600">Client Satisfaction</p>
          </div>

          <div className="text-center">
            <div className="w-16 h-16 bg-gradient-to-r from-green-500 to-teal-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <i className="ri-rocket-fill text-white text-2xl"></i>
            </div>
            <h3 className="text-3xl font-bold text-gray-900 mb-2">40%</h3>
            <p className="text-gray-600">Average CVR Increase</p>
          </div>
        </div>
      </div>
    </section>
  );
}
