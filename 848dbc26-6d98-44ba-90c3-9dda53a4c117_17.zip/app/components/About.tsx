
'use client';

import { useState, useEffect, useRef } from 'react';

export default function About() {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.3 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section ref={sectionRef} className="py-24 bg-white">
      <div className="container mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div className={`transform transition-all duration-1000 ${isVisible ? 'translate-x-0 opacity-100' : '-translate-x-20 opacity-0'}`}>
            <img 
              src="https://static.readdy.ai/image/49a0827f34fa0649c43ceb845d1bc172/aab0968feddc490d7f08e1f0ec0c1641.png"
              alt="Ahmad - Ahmify Designer"
              className="rounded-3xl shadow-2xl w-full h-96 object-cover object-top"
            />
          </div>

          <div className={`space-y-8 transform transition-all duration-1000 delay-300 ${isVisible ? 'translate-x-0 opacity-100' : 'translate-x-20 opacity-0'}`}>
            <div>
              <h2 className="text-5xl font-bold text-gray-900 mb-6">
                Meet <span className="bg-gradient-to-r from-pink-500 to-blue-500 bg-clip-text text-transparent">Ahmad Malik</span>
              </h2>
              <p className="text-xl text-gray-600 leading-relaxed">
                I turn products into stories, listings into eye-magnets, and brands into legends. From clean beauty to bold drinks, I help eCom brands look the way they should feel premium, fun, and built to sell.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div className="bg-gradient-to-r from-pink-50 to-pink-100 p-6 rounded-2xl">
                <div className="w-12 h-12 bg-pink-500 rounded-full flex items-center justify-center mb-4">
                  <i className="ri-trophy-fill text-white text-xl"></i>
                </div>
                <h3 className="font-bold text-gray-900 mb-2">100+</h3>
                <p className="text-gray-600">Projects Completed</p>
              </div>

              <div className="bg-gradient-to-r from-blue-50 to-blue-100 p-6 rounded-2xl">
                <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center mb-4">
                  <i className="ri-heart-fill text-white text-xl"></i>
                </div>
                <h3 className="font-bold text-gray-900 mb-2">98%</h3>
                <p className="text-gray-600">Client Satisfaction</p>
              </div>

              <div className="bg-gradient-to-r from-orange-50 to-orange-100 p-6 rounded-2xl">
                <div className="w-12 h-12 bg-orange-500 rounded-full flex items-center justify-center mb-4">
                  <i className="ri-time-fill text-white text-xl"></i>
                </div>
                <h3 className="font-bold text-gray-900 mb-2">5+</h3>
                <p className="text-gray-600">Years Experience</p>
              </div>

              <div className="bg-gradient-to-r from-purple-50 to-purple-100 p-6 rounded-2xl">
                <div className="w-12 h-12 bg-purple-500 rounded-full flex items-center justify-center mb-4">
                  <i className="ri-global-fill text-white text-xl"></i>
                </div>
                <h3 className="font-bold text-gray-900 mb-2">50+</h3>
                <p className="text-gray-600">Happy Clients</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
