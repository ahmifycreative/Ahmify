
'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';

export default function Hero() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  return (
    <section className="min-h-screen relative overflow-hidden bg-gradient-to-br from-pink-50 via-white to-blue-50">
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: `url('https://readdy.ai/api/search-image?query=Modern%20creative%20workspace%20with%20vibrant%20colors%2C%20design%20tools%2C%20Amazon%20product%20mockups%2C%20soft%20coral%20and%20blue%20tones%2C%20clean%20minimalist%20setup%20with%20laptop%2C%20graphics%20tablet%2C%20colorful%20sticky%20notes%2C%20bright%20natural%20lighting%2C%20contemporary%20office%20aesthetic%2C%20creative%20energy%2C%20productivity%20vibes&width=1920&height=1080&seq=hero-bg&orientation=landscape')`,
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-white/95 via-white/90 to-white/80"></div>
      </div>

      <div className="relative z-10 container mx-auto px-6 py-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center min-h-screen">
          <div className="space-y-8">
            <div className={`transform transition-all duration-1000 delay-300 ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0'}`}>
              <h1 className="text-6xl lg:text-7xl font-bold leading-tight">
                <span className="block text-gray-900">Designs That</span>
                <span className="block bg-gradient-to-r from-pink-500 to-blue-500 bg-clip-text text-transparent">Convert</span>
                <span className="block text-gray-900">Creativity That</span>
                <span className="block bg-gradient-to-r from-orange-500 to-pink-500 bg-clip-text text-transparent">Clicks</span>
              </h1>
            </div>

            <div className={`transform transition-all duration-1000 delay-500 ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0'}`}>
              <p className="text-xl text-gray-600 leading-relaxed max-w-lg">
                Hi, I'm Ahmad, your secret weapon for scroll-stopping, revenue-boosting graphics
              </p>
            </div>

            <div className={`transform transition-all duration-1000 delay-700 ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0'}`}>
              <Link href="https://vqwjnrai.formester.com/f/PhZdCkZOm" target="_blank" rel="noopener noreferrer" className="group relative inline-flex items-center justify-center px-12 py-4 bg-gradient-to-r from-pink-500 to-blue-500 text-white font-semibold rounded-full text-lg transition-all duration-300 hover:scale-105 hover:shadow-2xl whitespace-nowrap cursor-pointer">
                <span className="relative z-10">Let's Build Something Bold</span>
                <div className="absolute inset-0 bg-gradient-to-r from-pink-600 to-blue-600 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              </Link>
            </div>

            <div className={`flex items-center space-x-8 transform transition-all duration-1000 delay-900 ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0'}`}>
              <div className="flex items-center space-x-2">
                <div className="w-4 h-4 bg-green-500 rounded-full animate-pulse"></div>
                <span className="text-gray-700 font-medium">Available for projects</span>
              </div>
              <div className="flex items-center space-x-2">
                <i className="ri-star-fill text-yellow-400"></i>
                <span className="text-gray-700 font-medium">5.0 rating</span>
              </div>
            </div>
          </div>

          <div className={`relative transform transition-all duration-1000 delay-1100 ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0'}`}>
            <div className="relative">
              <div className="absolute -inset-4 bg-gradient-to-r from-pink-400 to-blue-400 rounded-3xl blur-xl opacity-30 animate-pulse"></div>
              <img 
                src="https://readdy.ai/api/search-image?query=Creative%20designer%20workspace%20mockup%20with%20Amazon%20product%20images%2C%20colorful%20design%20elements%2C%20modern%20laptop%20displaying%20ecommerce%20graphics%2C%20vibrant%20coral%20and%20blue%20color%20scheme%2C%20professional%20creative%20setup%2C%20design%20tools%2C%20mockup%20frames%2C%20contemporary%20aesthetic%2C%20bright%20lighting%2C%20inspiring%20creative%20environment&width=600&height=700&seq=hero-image&orientation=portrait"
                alt="Creative workspace"
                className="relative rounded-3xl shadow-2xl w-full h-96 object-cover object-top"
              />
            </div>
          </div>
        </div>
      </div>

      <div className="absolute bottom-10 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div className="w-8 h-8 flex items-center justify-center cursor-pointer">
          <i className="ri-arrow-down-line text-2xl text-gray-600"></i>
        </div>
      </div>
    </section>
  );
}
